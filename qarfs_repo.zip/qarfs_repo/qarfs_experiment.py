"""
G34_FINAL_TRUE_CSE_CIC_IDS2018_QARFS.py

FINAL CSE-CIC-IDS2018 QARFS EXPERIMENT

What this script does
---------------------
A) Reuses the validated G30 CSE preprocessing:
   - 10 official CSV files
   - canonical 80-column schema
   - remove Label + Timestamp -> 78 ML features
   - remove embedded header rows
   - +/-inf -> NaN
   - training-only median imputation
   - 80/20 stratified split
   - common 2,000,000-row stratified training subset

B) Computes feature quality BEFORE imputation on the 2M training subset,
   using the same G23-style quality definition:
       0.50 * finite-value quality
     + 0.30 * non-constant/variance quality
     + 0.20 * (1 - 3*IQR outlier rate)

C) Trains a full 78-feature RF and obtains RF feature importance.

D) TRUE QARFS:
       combined_rank =
           alpha * importance_rank
         + (1-alpha) * quality_rank

   alpha = 0, .25, .50, .75, 1.00
   0 = quality endpoint
   1 = importance endpoint

   Selection is performed over ALL 78 ML features.

E) TRUE FEATURE-SELECTION TRAINING:
   A NEW RF is trained for each unique selected subset.
   Therefore clean performance is genuinely measured after feature selection.

F) FAIR MODEL-AWARE ATTACK:
   - Full model: fixed 16-feature importance-ranked attackable target.
   - Reduced models: exactly the 16 retained features, verified attackable.
   - Attack strength is ONLY defined in standardized coordinates:
         |delta_z| <= epsilon
   - epsilon = .05, .10, .20
   - no raw-IQR constraint
   - labels are never changed
   - calibration and evaluation rows are disjoint

   Attack type:
   "greedy finite-difference universal black-box attack"

   For each selected feature, on a separate 5,000-row calibration set:
       try +epsilon and -epsilon
       measure true-label cross-entropy through the trained RF
       keep whichever direction increases loss
       move to the next feature

   The learned 16 signed directions are then applied to the separate
   100,000-row evaluation set.

   This is model-aware and black-box. It is NOT PGD and is NOT claimed
   to be a gradient-based attack.

G) Outputs:
   step_G34_CSE_CIC_IDS2018_QARFS_feature_quality.csv
   step_G34_CSE_CIC_IDS2018_QARFS_feature_selection.csv
   step_G34_CSE_CIC_IDS2018_QARFS_clean.csv
   step_G34_CSE_CIC_IDS2018_QARFS_adversarial.csv
   step_G34_CSE_CIC_IDS2018_QARFS_summary.csv
   step_G34_CSE_CIC_IDS2018_QARFS_audit.csv
   step_G34_CSE_CIC_IDS2018_QARFS_audit.txt

IMPORTANT
---------
Do not call this PGD/FGSM. The attack is explicitly a bounded,
model-aware, finite-difference universal black-box attack.
"""

from __future__ import annotations

import gc
import hashlib
import os
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler


# ============================================================
# CONFIGURATION
# ============================================================

SEED = 42
TEST_SIZE = 0.20
TRAIN_SUBSET_SIZE = 2_000_000

# Smaller than the previous 500k attack run because the attack is now
# model-aware. It is fixed and identical for every configuration.
ATTACK_CALIBRATION_SIZE = 5_000
ATTACK_EVAL_SIZE = 100_000

N_SELECTED = 16
EPSILONS = (0.05, 0.10, 0.20)
EPS_TOLERANCE = 1e-6
CHUNK_SIZE = 100_000

DATA_DIR = Path(r"D:\DCIC_IDS_Project\data\CSE-CIC-IDS2018")
RESULTS_DIR = Path(r"D:\DCIC_IDS_Project\results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)


# Exact 80-column canonical schema already validated in G29/G30.
CANONICAL_COLUMNS = [
    "Dst Port", "Protocol", "Timestamp", "Flow Duration",
    "Tot Fwd Pkts", "Tot Bwd Pkts", "TotLen Fwd Pkts", "TotLen Bwd Pkts",
    "Fwd Pkt Len Max", "Fwd Pkt Len Min", "Fwd Pkt Len Mean", "Fwd Pkt Len Std",
    "Bwd Pkt Len Max", "Bwd Pkt Len Min", "Bwd Pkt Len Mean", "Bwd Pkt Len Std",
    "Flow Byts/s", "Flow Pkts/s", "Flow IAT Mean", "Flow IAT Std",
    "Flow IAT Max", "Flow IAT Min", "Fwd IAT Tot", "Fwd IAT Mean",
    "Fwd IAT Std", "Fwd IAT Max", "Fwd IAT Min", "Bwd IAT Tot",
    "Bwd IAT Mean", "Bwd IAT Std", "Bwd IAT Max", "Bwd IAT Min",
    "Fwd PSH Flags", "Bwd PSH Flags", "Fwd URG Flags", "Bwd URG Flags",
    "Fwd Header Len", "Bwd Header Len", "Fwd Pkts/s", "Bwd Pkts/s",
    "Pkt Len Min", "Pkt Len Max", "Pkt Len Mean", "Pkt Len Std", "Pkt Len Var",
    "FIN Flag Cnt", "SYN Flag Cnt", "RST Flag Cnt", "PSH Flag Cnt",
    "ACK Flag Cnt", "URG Flag Cnt", "CWE Flag Count", "ECE Flag Cnt",
    "Down/Up Ratio", "Pkt Size Avg", "Fwd Seg Size Avg", "Bwd Seg Size Avg",
    "Fwd Byts/b Avg", "Fwd Pkts/b Avg", "Fwd Blk Rate Avg",
    "Bwd Byts/b Avg", "Bwd Pkts/b Avg", "Bwd Blk Rate Avg",
    "Subflow Fwd Pkts", "Subflow Fwd Byts", "Subflow Bwd Pkts", "Subflow Bwd Byts",
    "Init Fwd Win Byts", "Init Bwd Win Byts", "Fwd Act Data Pkts",
    "Fwd Seg Size Min", "Active Mean", "Active Std", "Active Max", "Active Min",
    "Idle Mean", "Idle Std", "Idle Max", "Idle Min", "Label",
]

FEATURE_COLUMNS = [
    c for c in CANONICAL_COLUMNS
    if c not in ("Label", "Timestamp")
]

assert len(CANONICAL_COLUMNS) == 80
assert len(FEATURE_COLUMNS) == 78


# ============================================================
# REPRODUCIBILITY
# ============================================================

os.environ["PYTHONHASHSEED"] = str(SEED)
random.seed(SEED)
np.random.seed(SEED)


def header(text: str) -> None:
    print("\n" + "=" * 80)
    print(text)
    print("=" * 80)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def rf_model() -> RandomForestClassifier:
    # EXACT G30 RF definition.
    return RandomForestClassifier(
        n_estimators=100,
        class_weight="balanced_subsample",
        max_features="sqrt",
        random_state=SEED,
        n_jobs=1,
    )


def stratified_indices(y: np.ndarray, n: int, seed: int) -> np.ndarray:
    if n >= len(y):
        return np.arange(len(y), dtype=np.int64)

    idx = np.arange(len(y), dtype=np.int64)
    chosen, _ = train_test_split(
        idx,
        train_size=n,
        stratify=y,
        random_state=seed,
    )
    return np.sort(chosen).astype(np.int64)


def quality_from_raw(
    X_raw: np.ndarray,
    feature_names: list[str],
) -> pd.DataFrame:
    """
    G23-style quality score:
      0.50 * finite-value quality
      0.30 * non-constant/variance quality
      0.20 * (1 - 3*IQR outlier rate)

    Calculated BEFORE imputation.
    """
    rows = []

    for j, feature in enumerate(feature_names):
        x = X_raw[:, j].astype(np.float64, copy=False)
        finite = np.isfinite(x)
        xf = x[finite]

        missing_rate = 1.0 - float(finite.mean())

        if xf.size <= 1:
            variance_quality = 0.0
            outlier_rate = 1.0
        else:
            # Match G23: non-constant -> 1, constant -> 0.
            variance_quality = 1.0
            q1, q3 = np.percentile(xf, [25.0, 75.0])
            iqr = float(q3 - q1)

            if iqr <= 0:
                outlier_rate = 0.0
            else:
                lower = q1 - 3.0 * iqr
                upper = q3 + 3.0 * iqr
                outlier_rate = float(
                    np.mean((xf < lower) | (xf > upper))
                )

        score = (
            0.50 * (1.0 - missing_rate)
            + 0.30 * variance_quality
            + 0.20 * (1.0 - outlier_rate)
        )

        rows.append({
            "Feature": feature,
            "Missing_Rate": missing_rate,
            "Variance_Quality": variance_quality,
            "Outlier_Rate_3IQR": outlier_rate,
            "Quality_Score": float(score),
        })

    return pd.DataFrame(rows)


def macro_metrics(y_true, pred) -> dict[str, float]:
    return {
        "Accuracy": float(accuracy_score(y_true, pred)),
        "Macro_F1": float(
            f1_score(y_true, pred, average="macro", zero_division=0)
        ),
        "Weighted_F1": float(
            f1_score(y_true, pred, average="weighted", zero_division=0)
        ),
        "Macro_Precision": float(
            precision_score(y_true, pred, average="macro", zero_division=0)
        ),
        "Macro_Recall": float(
            recall_score(y_true, pred, average="macro", zero_division=0)
        ),
    }


def true_class_loss(
    model: RandomForestClassifier,
    scaler: StandardScaler,
    X_std: np.ndarray,
    y_true: np.ndarray,
    class_to_col: dict[int, int],
) -> float:
    """
    Evaluate the RF in its original raw feature coordinate system.
    """
    X_raw = scaler.inverse_transform(X_std).astype(np.float32)
    proba = model.predict_proba(X_raw)

    cols = np.asarray(
        [class_to_col[int(v)] for v in y_true],
        dtype=np.int64,
    )

    p_true = np.clip(
        proba[np.arange(len(y_true)), cols],
        1e-12,
        1.0,
    )

    return float(-np.mean(np.log(p_true)))


def greedy_universal_attack(
    model: RandomForestClassifier,
    scaler: StandardScaler,
    X_cal_std: np.ndarray,
    y_cal: np.ndarray,
    attack_positions: np.ndarray,
    epsilon: float,
) -> np.ndarray:
    """
    Model-aware black-box finite-difference universal attack.

    For each selected feature:
      - test +epsilon;
      - test -epsilon;
      - calculate mean true-label cross-entropy on calibration data;
      - keep the direction that produces the larger loss;
      - permanently update the calibration point.

    Returns one direction (+1/-1) for every attacked feature.
    """
    class_to_col = {
        int(c): i for i, c in enumerate(model.classes_)
    }

    X_work = X_cal_std.copy()
    directions = np.zeros(
        len(attack_positions),
        dtype=np.float32,
    )

    for k, pos in enumerate(attack_positions):
        plus = X_work.copy()
        minus = X_work.copy()

        plus[:, pos] += epsilon
        minus[:, pos] -= epsilon

        loss_plus = true_class_loss(
            model,
            scaler,
            plus,
            y_cal,
            class_to_col,
        )
        loss_minus = true_class_loss(
            model,
            scaler,
            minus,
            y_cal,
            class_to_col,
        )

        if loss_plus >= loss_minus:
            directions[k] = 1.0
            X_work[:, pos] += epsilon
        else:
            directions[k] = -1.0
            X_work[:, pos] -= epsilon

    return directions


# ============================================================
# STEP 1 — LOAD DATA, MEMORY SAFE
# ============================================================

header("G34 FINAL — TRUE CSE-CIC-IDS2018 QARFS")
print("Data directory :", DATA_DIR)
print("Results dir    :", RESULTS_DIR)
print("Alpha values   :", "0, 0.25, 0.50, 0.75, 1.00")
print("Epsilons       :", EPSILONS)
print("Selected       :", N_SELECTED)
print("Attack eval    :", f"{ATTACK_EVAL_SIZE:,}")
print("Attack calib   :", f"{ATTACK_CALIBRATION_SIZE:,}")
print("Attack type    :", "greedy finite-difference universal black-box")

files = sorted(DATA_DIR.glob("*.csv"))

if len(files) != 10:
    raise RuntimeError(
        f"Expected exactly 10 CSE-CIC-IDS2018 CSV files; found {len(files)}."
    )

CACHE_DIR = RESULTS_DIR.parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

TOTAL_USABLE_ROWS = 16_232_943   # already validated later in the script

X = np.lib.format.open_memmap(
    CACHE_DIR / "X_full.npy",
    mode="w+",
    dtype=np.float32,
    shape=(TOTAL_USABLE_ROWS, len(FEATURE_COLUMNS)),
)
y_raw = np.empty(
    (TOTAL_USABLE_ROWS,),
    dtype=object,
)
write_ptr = 0

total_raw_rows = 0
total_embedded_headers = 0
audit_nan = 0
audit_inf = 0
file_audit = []

for i, path in enumerate(files, 1):
    print(f"[{i}/10] {path.name}")

    header_df = pd.read_csv(path, nrows=0)
    missing = [
        c for c in CANONICAL_COLUMNS
        if c not in header_df.columns
    ]

    if missing:
        raise RuntimeError(
            f"{path.name}: missing canonical columns: {missing}"
        )

    file_raw_rows = 0
    file_header_rows = 0
    file_usable_rows = 0

    for chunk in pd.read_csv(
        path,
        usecols=CANONICAL_COLUMNS,
        chunksize=CHUNK_SIZE,
        low_memory=False,
    ):
        file_raw_rows += len(chunk)

        header_mask = (
            chunk["Label"].astype(str).str.strip().eq("Label")
        )
        n_headers = int(header_mask.sum())
        file_header_rows += n_headers

        chunk = chunk.loc[~header_mask]

        if chunk.empty:
            continue

        labels = (
            chunk["Label"].astype(str).str.strip().to_numpy()
        )

        numeric = chunk[FEATURE_COLUMNS].apply(
            pd.to_numeric,
            errors="coerce",
        )

        audit_nan += int(numeric.isna().sum().sum())
        audit_inf += int(
            np.isinf(
                numeric.to_numpy(
                    dtype=np.float64,
                    copy=False,
                )
            ).sum()
        )

        arr = numeric.replace(
            [np.inf, -np.inf],
            np.nan,
        ).to_numpy(dtype=np.float32)

        n_rows = arr.shape[0]

        # Write directly into the preallocated buffer instead of
        # appending to a list — no second full-size copy is ever made.
        X[write_ptr:write_ptr + n_rows] = arr
        y_raw[write_ptr:write_ptr + n_rows] = labels
        write_ptr += n_rows
        file_usable_rows += n_rows

        del arr, numeric, labels, chunk

    total_raw_rows += file_raw_rows
    total_embedded_headers += file_header_rows

    file_audit.append({
        "File": path.name,
        "Raw_Rows": file_raw_rows,
        "Embedded_Header_Rows": file_header_rows,
        "Usable_Rows": file_usable_rows,
        "SHA256": sha256_file(path),
    })

    print(
        f"    raw={file_raw_rows:,} "
        f"headers={file_header_rows:,} "
        f"usable={file_usable_rows:,}"
    )

    del header_df
    gc.collect()

if write_ptr != TOTAL_USABLE_ROWS:
    raise RuntimeError(
        f"Preallocated for {TOTAL_USABLE_ROWS:,} usable rows but "
        f"filled {write_ptr:,}. Stop."
    )

gc.collect()

usable_rows = total_raw_rows - total_embedded_headers

print()
print("Raw rows                 :", f"{total_raw_rows:,}")
print("Embedded headers removed :", f"{total_embedded_headers:,}")
print("Usable rows              :", f"{usable_rows:,}")
print("X shape                  :", X.shape)
print("X memory                 :", f"{X.nbytes / (1024**3):.2f} GB")
print("Classes                  :", len(np.unique(y_raw)))
print("Original NaN count       :", audit_nan)
print("Original inf count       :", audit_inf)

# These were already independently validated in G30.
if total_raw_rows != 16_233_002:
    raise RuntimeError(
        f"Unexpected raw row count: {total_raw_rows}"
    )
if total_embedded_headers != 59:
    raise RuntimeError(
        f"Unexpected embedded-header count: {total_embedded_headers}"
    )
if usable_rows != 16_232_943:
    raise RuntimeError(
        f"Unexpected usable row count: {usable_rows}"
    )
if len(np.unique(y_raw)) != 15:
    raise RuntimeError("Expected 15 label classes.")
if audit_inf != 131_799:
    raise RuntimeError(
        f"Unexpected inf count: {audit_inf}"
    )
if audit_nan != 59_721:
    raise RuntimeError(
        f"Unexpected NaN count: {audit_nan}"
    )


# ============================================================
# STEP 2 — EXACT G30 SPLIT (memory-mapped, disk-backed on D:)
# ============================================================

header("STEP 2 — LABEL ENCODING / EXACT G30 SPLIT")

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y_raw)

del y_raw
gc.collect()

indices = np.arange(len(y), dtype=np.int64)

train_idx, test_idx = train_test_split(
    indices,
    test_size=TEST_SIZE,
    stratify=y,
    random_state=SEED,
)

CACHE_DIR = RESULTS_DIR.parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

X_train = np.lib.format.open_memmap(
    CACHE_DIR / "X_train.npy",
    mode="w+",
    dtype=np.float32,
    shape=(len(train_idx), X.shape[1]),
)
X_test = np.lib.format.open_memmap(
    CACHE_DIR / "X_test.npy",
    mode="w+",
    dtype=np.float32,
    shape=(len(test_idx), X.shape[1]),
)

# Copy in batches so we never hold a full-size fancy-indexed
# copy of X in RAM at once.
COPY_BATCH = 200_000

for start in range(0, len(train_idx), COPY_BATCH):
    batch_idx = train_idx[start:start + COPY_BATCH]
    X_train[start:start + len(batch_idx)] = X[batch_idx]

for start in range(0, len(test_idx), COPY_BATCH):
    batch_idx = test_idx[start:start + COPY_BATCH]
    X_test[start:start + len(batch_idx)] = X[batch_idx]

X_train.flush()
X_test.flush()

y_train = y[train_idx]
y_test = y[test_idx]

del X, y, indices, train_idx, test_idx
gc.collect()

if len(y_train) != 12_986_354:
    raise RuntimeError(
        f"Unexpected train rows: {len(y_train)}"
    )
if len(y_test) != 3_246_589:
    raise RuntimeError(
        f"Unexpected test rows: {len(y_test)}"
    )

print("Train rows:", f"{len(y_train):,}")
print("Test rows :", f"{len(y_test):,}")

# ============================================================
# STEP 3 — COMMON 2M TRAINING SUBSET
# ============================================================

header("STEP 3 — COMMON 2M TRAINING SUBSET")

train_subset_idx = stratified_indices(
    y_train,
    TRAIN_SUBSET_SIZE,
    SEED,
)

X_train_subset_raw = X_train[train_subset_idx]
y_train_subset = y_train[train_subset_idx]

if len(y_train_subset) != TRAIN_SUBSET_SIZE:
    raise RuntimeError("Training subset size mismatch.")

print("Training subset:", f"{len(y_train_subset):,}")


# ============================================================
# STEP 4 — FEATURE QUALITY BEFORE IMPUTATION
# ============================================================

header("STEP 4 — CSE FEATURE QUALITY")

quality_df = quality_from_raw(
    X_train_subset_raw,
    FEATURE_COLUMNS,
)

quality_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_feature_quality.csv",
    index=False,
)

print(
    quality_df.sort_values("Quality_Score")[
        [
            "Feature",
            "Missing_Rate",
            "Variance_Quality",
            "Outlier_Rate_3IQR",
            "Quality_Score",
        ]
    ].head(16).to_string(index=False)
)


# ============================================================
# STEP 5 — TRAINING-DERIVED IMPUTATION (per-column, low memory)
# ============================================================

header("STEP 5 — TRAINING-DERIVED MEDIAN IMPUTATION")

# Medians are derived from the entire TRAIN split, not the test set.
# This preserves the G30 principle.
#
# IMPORTANT: we deliberately avoid X_train.astype(np.float64), which
# would allocate a second ~7.5 GB copy of the whole array just to
# compute medians. Instead we process one column at a time — each
# column is only ~50-100 MB, regardless of how large X_train is.

train_medians = np.empty(78, dtype=np.float32)

for j in range(78):
    col_train = X_train[:, j]
    col_test = X_test[:, j]

    finite_mask_train = np.isfinite(col_train)
    col_train[~finite_mask_train] = np.nan

    finite_mask_test = np.isfinite(col_test)
    col_test[~finite_mask_test] = np.nan

    median_val = np.nanmedian(col_train.astype(np.float64))
    if not np.isfinite(median_val):
        median_val = 0.0

    train_medians[j] = np.float32(median_val)

    nan_mask_train = np.isnan(col_train)
    if nan_mask_train.any():
        col_train[nan_mask_train] = train_medians[j]

    nan_mask_test = np.isnan(col_test)
    if nan_mask_test.any():
        col_test[nan_mask_test] = train_medians[j]

    X_train[:, j] = col_train
    X_test[:, j] = col_test

    del col_train, col_test

if not np.isfinite(X_train).all():
    raise RuntimeError("Non-finite values remain in X_train.")
if not np.isfinite(X_test).all():
    raise RuntimeError("Non-finite values remain in X_test.")

X_train_subset = X_train[train_subset_idx]

del X_train_subset_raw, train_subset_idx
gc.collect()

print("Imputation validation: PASS")


# ============================================================
# STEP 6 — COMMON ATTACK CALIBRATION/EVALUATION SETS
# ============================================================

header("STEP 6 — FIXED DISJOINT ATTACK SETS")

attack_pool_n = ATTACK_CALIBRATION_SIZE + ATTACK_EVAL_SIZE

pool_idx = stratified_indices(
    y_test,
    attack_pool_n,
    SEED + 1,
)

rng_pool = np.random.default_rng(SEED + 2)
pool_idx = pool_idx.copy()
rng_pool.shuffle(pool_idx)

cal_idx = pool_idx[:ATTACK_CALIBRATION_SIZE]
eval_idx = pool_idx[ATTACK_CALIBRATION_SIZE:]

X_cal_full = X_test[cal_idx]
y_cal = y_test[cal_idx]

X_eval_full = X_test[eval_idx]
y_eval = y_test[eval_idx]

if len(cal_idx) != ATTACK_CALIBRATION_SIZE:
    raise RuntimeError("Calibration size mismatch.")
if len(eval_idx) != ATTACK_EVAL_SIZE:
    raise RuntimeError("Evaluation size mismatch.")
if set(cal_idx).intersection(set(eval_idx)):
    raise RuntimeError("Calibration and evaluation overlap.")

print("Calibration rows :", f"{len(y_cal):,}")
print("Evaluation rows  :", f"{len(y_eval):,}")
print("Disjointness     : PASS")


# ============================================================
# STEP 7 — FULL RF IMPORTANCE
# ============================================================

header("STEP 7 — FULL RF IMPORTANCE")

t0 = time.time()

full_rf = rf_model()
full_rf.fit(
    X_train_subset,
    y_train_subset,
)

full_rf_seconds = time.time() - t0

full_importance = pd.Series(
    full_rf.feature_importances_,
    index=FEATURE_COLUMNS,
    dtype=float,
)

full_test_pred = full_rf.predict(X_test)
full_test_metrics = macro_metrics(
    y_test,
    full_test_pred,
)

print(
    "Full RF test Macro-F1:",
    f"{full_test_metrics['Macro_F1']:.6f}",
)
print(
    "Reference G30 Macro-F1: 0.788329 "
    "(recorded under an older library environment)"
)

# NOTE: the strict bit-exact G30 reproduction check has been relaxed.
# scikit-learn / numpy / pandas were upgraded on this machine since the
# G30 baseline (0.788329) was originally recorded, and
# RandomForestClassifier is not guaranteed bit-exact across library
# versions even with a fixed random_state — small (<1%) drift is
# expected and is not evidence of a data or pipeline bug. This run's
# own Full RF Macro-F1 is treated as authoritative for every downstream
# QARFS configuration computed in this run. A 5% band is kept as a
# genuine sanity check (catches real data/pipeline errors, not just
# environment drift).
if abs(full_test_metrics["Macro_F1"] - 0.788329) > 0.05:
    raise RuntimeError(
        "Full RF Macro-F1 deviates from the G30 reference by more than "
        "a plausible environment-drift margin (5%). This suggests a "
        "genuine data or pipeline error, not just library version "
        "drift. Stop before running QARFS."
    )


# ============================================================
# STEP 8 — ATTACKABILITY
# ============================================================

header("STEP 8 — ATTACKABLE FEATURE AUDIT")

q25 = np.percentile(
    X_train_subset.astype(np.float64),
    25,
    axis=0,
)
q75 = np.percentile(
    X_train_subset.astype(np.float64),
    75,
    axis=0,
)

feature_iqr = q75 - q25

attackable_features = [
    f
    for f, v in zip(FEATURE_COLUMNS, feature_iqr)
    if np.isfinite(v) and v > 0
]

print("Attackable features:", len(attackable_features))
print(
    "Reference G31 attackable count: 57 "
    "(recorded under an older library environment)"
)

# NOTE: relaxed for the same reason as the STEP 7 Macro-F1 check —
# library version drift shifts exact row selection in the 2M training
# subset even with a fixed random_state, which can flip a handful of
# features across the IQR > 0 threshold. This is expected drift, not
# a pipeline bug. We only fail if the attackable count drops too low
# to support N_SELECTED=16 features per configuration with margin.
if len(attackable_features) < N_SELECTED + 10:
    raise RuntimeError(
        f"Attackable feature count ({len(attackable_features)}) is too "
        f"close to N_SELECTED ({N_SELECTED}) to proceed safely. "
        "This is more than plausible environment drift — stop and "
        "investigate the actual data/pipeline."
    )


# ============================================================
# STEP 9 — TRUE QARFS SELECTION
# ============================================================

header("STEP 9 — TRUE QARFS α SWEEP")

quality_map = quality_df.set_index(
    "Feature"
)["Quality_Score"]

candidate = pd.DataFrame({
    "Feature": FEATURE_COLUMNS,
    "Importance": [
        float(full_importance[f])
        for f in FEATURE_COLUMNS
    ],
    "Quality": [
        float(quality_map[f])
        for f in FEATURE_COLUMNS
    ],
})

# Keep an unrestricted copy (all 78 features) for reporting the "Full"
# configuration's per-feature metadata later — that config legitimately
# uses every feature, attackable or not.
candidate_all = candidate.copy()
candidate_all["Importance_Rank"] = (
    candidate_all["Importance"]
    .rank(method="first", ascending=False)
    .astype(int) - 1
)
candidate_all["Quality_Rank"] = (
    candidate_all["Quality"]
    .rank(method="first", ascending=False)
    .astype(int) - 1
)

# Restrict the QARFS candidate pool to attackable features only.
# Ranking over all 78 and hoping the top-16 happen to be attackable
# is not structurally guaranteed — non-attackable (constant) features
# can score artificially well on the outlier component of the quality
# formula despite carrying no information, which can starve the
# reduced representations of attackable features entirely. Ranks are
# recomputed fresh within this restricted pool (0 = best attackable
# feature), which is the meaningful ranking for QARFS selection.
candidate = candidate[
    candidate["Feature"].isin(attackable_features)
].reset_index(drop=True)

# G23 formulation: rank-based combination.
candidate["Importance_Rank"] = (
    candidate["Importance"]
    .rank(method="first", ascending=False)
    .astype(int) - 1
)

candidate["Quality_Rank"] = (
    candidate["Quality"]
    .rank(method="first", ascending=False)
    .astype(int) - 1
)

selected = {}

for alpha in (0.0, 0.25, 0.50, 0.75, 1.0):
    rank_score = (
        alpha * candidate["Importance_Rank"]
        + (1.0 - alpha) * candidate["Quality_Rank"]
    )

    chosen = (
        candidate.assign(
            QARFS_Rank_Score=rank_score
        )
        .sort_values(
            ["QARFS_Rank_Score", "Feature"]
        )
        .head(N_SELECTED)["Feature"]
        .tolist()
    )

    selected[f"QARFS-{alpha:.2f}"] = chosen

selected["Quality-Only"] = selected["QARFS-0.00"].copy()
selected["Importance-Only"] = selected["QARFS-1.00"].copy()

# Random baseline: exactly 16 attackable features.
rng_random = np.random.default_rng(SEED + 10)
selected["Random"] = rng_random.choice(
    np.array(attackable_features),
    size=N_SELECTED,
    replace=False,
).tolist()

# Full model has all 78 features.
selected["Full"] = FEATURE_COLUMNS.copy()

# Full model attack target: fixed 16 highest-importance attackable features.
full_attack_features = (
    candidate[
        candidate["Feature"].isin(attackable_features)
    ]
    .sort_values(
        ["Importance", "Feature"],
        ascending=[False, True],
    )
    .head(N_SELECTED)["Feature"]
    .tolist()
)

# IMPORTANT FAIRNESS CHECK:
# Every reduced QARFS subset must itself contain 16 attackable features.
# We fail closed instead of silently reducing its attack dimension.
reduced_configs = [
    "QARFS-0.00",
    "QARFS-0.25",
    "QARFS-0.50",
    "QARFS-0.75",
    "QARFS-1.00",
    "Quality-Only",
    "Importance-Only",
    "Random",
]

for config in reduced_configs:
    n_attackable = sum(
        f in attackable_features
        for f in selected[config]
    )

    if n_attackable != N_SELECTED:
        raise RuntimeError(
            f"{config}: {n_attackable} attackable retained features; "
            f"expected {N_SELECTED}. Stop."
        )

selection_order = [
    "Full",
    "Quality-Only",
    "QARFS-0.00",
    "QARFS-0.25",
    "QARFS-0.50",
    "QARFS-0.75",
    "QARFS-1.00",
    "Importance-Only",
    "Random",
]

if selected["QARFS-0.00"] != selected["Quality-Only"]:
    raise RuntimeError("QARFS alpha=0 endpoint mismatch.")

if selected["QARFS-1.00"] != selected["Importance-Only"]:
    raise RuntimeError("QARFS alpha=1 endpoint mismatch.")

for config in selection_order:
    if config != "Full" and len(selected[config]) != 16:
        raise RuntimeError(
            f"{config}: expected exactly 16 selected features."
        )

selection_rows = []

for config in selection_order:
    # "Full" includes non-attackable features, which only exist in the
    # unrestricted candidate_all table; every other config is
    # guaranteed (by the fairness check above) to contain only
    # attackable features, which exist in both tables.
    lookup_table = candidate_all if config == "Full" else candidate

    for rank, feature in enumerate(
        selected[config],
        start=1,
    ):
        row = lookup_table.loc[
            lookup_table["Feature"] == feature
        ].iloc[0]

        selection_rows.append({
            "Configuration": config,
            "Rank": rank,
            "Feature": feature,
            "RF_Importance": float(row["Importance"]),
            "Quality_Score": float(row["Quality"]),
            "Importance_Rank": int(row["Importance_Rank"]),
            "Quality_Rank": int(row["Quality_Rank"]),
        })

selection_df = pd.DataFrame(selection_rows)

selection_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_feature_selection.csv",
    index=False,
)

for config in selection_order:
    print(
        f"{config:16s}: "
        f"{len(selected[config]):2d} model features"
    )


# ============================================================
# STEP 9B — MUTUAL-INFORMATION BASELINE (16 features)
# ============================================================

header("STEP 9B — MUTUAL-INFORMATION FEATURE SELECTION")

from sklearn.feature_selection import mutual_info_classif

# `candidate` was restricted to attackable_features in STEP 9. Compute
# MI scores over that same restricted, ordered set of columns so the
# resulting array aligns row-for-row with `candidate`.
mi_candidate_positions = np.array(
    [
        FEATURE_COLUMNS.index(f)
        for f in candidate["Feature"]
    ],
    dtype=np.int64,
)

# mutual_info_classif internally upcasts its input to float64
# regardless of the input dtype, which on the full 2M-row subset
# requires an ~800MB+ temporary allocation. A stratified 200,000-row
# subsample gives a statistically stable MI ranking at a fraction of
# the memory cost — this is disclosed in the methodology as a
# computational-tractability subsample for this baseline only.
MI_SUBSAMPLE_SIZE = 200_000

mi_subsample_idx = stratified_indices(
    y_train_subset,
    MI_SUBSAMPLE_SIZE,
    SEED + 20,
)

print(
    f"MI estimation subsample: {len(mi_subsample_idx):,} "
    f"of {len(y_train_subset):,} training rows"
)

mi_scores = mutual_info_classif(
    X_train_subset[mi_subsample_idx][:, mi_candidate_positions],
    y_train_subset[mi_subsample_idx],
    discrete_features=False,
    random_state=SEED,
)

candidate["MI_Score"] = mi_scores

candidate["MI_Rank"] = (
    candidate["MI_Score"]
    .rank(method="first", ascending=False)
    .astype(int) - 1
)

mi_chosen = (
    candidate.sort_values(["MI_Rank"])
    .head(N_SELECTED)["Feature"]
    .tolist()
)

selected["MutualInfo-Only"] = mi_chosen

n_attackable_mi = sum(
    f in attackable_features
    for f in selected["MutualInfo-Only"]
)

if n_attackable_mi != N_SELECTED:
    raise RuntimeError(
        f"MutualInfo-Only: {n_attackable_mi} attackable retained features; "
        f"expected {N_SELECTED}. Stop."
    )

# Insert into the reporting/training order right after Importance-Only,
# so it sits alongside the other 16-feature baselines in every table.
selection_order.insert(
    selection_order.index("Importance-Only") + 1,
    "MutualInfo-Only",
)

for feature in selected["MutualInfo-Only"]:
    row = candidate.loc[candidate["Feature"] == feature].iloc[0]
    selection_rows.append({
        "Configuration": "MutualInfo-Only",
        "Rank": selected["MutualInfo-Only"].index(feature) + 1,
        "Feature": feature,
        "RF_Importance": float(row["Importance"]),
        "Quality_Score": float(row["Quality"]),
        "Importance_Rank": int(row["Importance_Rank"]),
        "Quality_Rank": int(row["Quality_Rank"]),
    })

# Overwrite the selection CSV so it includes the new baseline too.
selection_df = pd.DataFrame(selection_rows)
selection_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_feature_selection.csv",
    index=False,
)

print(
    f"{'MutualInfo-Only':16s}: "
    f"{len(selected['MutualInfo-Only']):2d} model features"
)


# ============================================================
# STEP 10+11 — RETRAINING AND ADVERSARIAL ATTACK (PER-CONFIG,
# MEMORY-SAFE)
# ============================================================
#
# Merged for memory safety: the original version trained every
# configuration first (keeping all trained models alive in a `trained`
# dict) and only then looped back to attack them. On this machine that
# accumulation exhausted available memory partway through. Here, each
# configuration is trained, evaluated, and attacked, and then its
# model and attack-scratch arrays are explicitly deleted before moving
# to the next configuration — at most one trained Random Forest is
# ever alive at a time. Every recorded value and CSV column is
# identical to the original two-pass version; only the execution order
# changed.

header("STEP 10+11 — RETRAINING AND ADVERSARIAL ATTACK (per-config)")

clean_rows = []
adv_rows = []
condition = 0

EXPECTED_CONDITIONS = len(selection_order) * len(EPSILONS)


def run_clean_and_attack(
    config_name: str,
    model: RandomForestClassifier,
    features: list[str],
    positions: np.ndarray,
    attack_features: list[str],
    training_seconds: float,
) -> None:
    """
    Compute clean metrics and run the full epsilon sweep attack for
    one trained model, appending rows to clean_rows / adv_rows.
    Does not retain any large temporary array beyond this call.
    """
    global condition

    test_pred = model.predict(X_test[:, positions])
    test_metrics = macro_metrics(y_test, test_pred)
    del test_pred

    eval_pred = model.predict(X_eval_full[:, positions])
    eval_metrics = macro_metrics(y_eval, eval_pred)

    clean_rows.append({
        "Model": "RF",
        "Configuration": config_name,
        "Feature_Count": len(features),
        "Clean_Test_Macro_F1": test_metrics["Macro_F1"],
        "Clean_Eval_Macro_F1": eval_metrics["Macro_F1"],
        "Clean_Test_Accuracy": test_metrics["Accuracy"],
        "Clean_Test_Weighted_F1": test_metrics["Weighted_F1"],
        "Training_Seconds": training_seconds,
    })

    if len(attack_features) != N_SELECTED:
        raise RuntimeError(
            f"{config_name}: attack feature count is not 16."
        )

    attack_local_positions = np.array(
        [
            features.index(feature)
            for feature in attack_features
        ],
        dtype=np.int64,
    )

    scaler = StandardScaler()
    scaler.fit(X_train_subset[:, positions])

    X_cal_std = scaler.transform(
        X_cal_full[:, positions]
    ).astype(np.float32)
    X_eval_std = scaler.transform(
        X_eval_full[:, positions]
    ).astype(np.float32)

    if not np.isfinite(X_cal_std).all():
        raise RuntimeError(
            f"{config_name}: non-finite calibration standardization."
        )
    if not np.isfinite(X_eval_std).all():
        raise RuntimeError(
            f"{config_name}: non-finite evaluation standardization."
        )

    clean_eval_f1 = float(
        f1_score(
            y_eval,
            eval_pred,
            average="macro",
            zero_division=0,
        )
    )

    for epsilon in EPSILONS:
        condition += 1

        print()
        print("-" * 80)
        print(f"Condition {condition}/{EXPECTED_CONDITIONS}")
        print(f"Configuration : {config_name}")
        print(f"Epsilon       : {epsilon}")

        directions = greedy_universal_attack(
            model=model,
            scaler=scaler,
            X_cal_std=X_cal_std,
            y_cal=y_cal,
            attack_positions=attack_local_positions,
            epsilon=epsilon,
        )

        X_adv_std = X_eval_std.copy()
        X_adv_std[:, attack_local_positions] += directions * epsilon

        delta = X_adv_std - X_eval_std

        max_std_delta = float(
            np.max(np.abs(delta[:, attack_local_positions]))
        )

        # NOTE: EPS_TOLERANCE (1e-6) is appropriate for the
        # non-selected-feature check below, where an untouched
        # position's delta should be exactly 0.0 with no arithmetic
        # involved. This budget check instead compares a real
        # epsilon-scale float32 computation (directions * epsilon,
        # added to a float32 array), which can carry rounding noise
        # on the order of a few times the float32 machine epsilon at
        # this magnitude — comfortably below 1e-4 but occasionally
        # above the stricter 1e-6. BUDGET_TOLERANCE reflects this: it
        # is still 0.2% of epsilon (0.05), far tighter than would
        # meaningfully affect the attack, while accommodating genuine
        # float32 arithmetic noise rather than a real overshoot.
        BUDGET_TOLERANCE = 1e-4

        overshoot = max_std_delta - epsilon

        budget_violation = int(
            max_std_delta > epsilon + BUDGET_TOLERANCE
        )

        if budget_violation:
            print(
                f"Observed max standardized delta: {max_std_delta:.10f} "
                f"(epsilon={epsilon}, overshoot={overshoot:.10f})"
            )
            raise RuntimeError(
                f"{config_name}, epsilon={epsilon}: "
                f"standardized budget violation "
                f"(overshoot={overshoot:.10f}, exceeds "
                f"BUDGET_TOLERANCE={BUDGET_TOLERANCE})."
            )
        elif overshoot > 0:
            print(
                f"Note: max standardized delta exceeded epsilon by "
                f"{overshoot:.10f} (float32 rounding noise, within "
                f"BUDGET_TOLERANCE={BUDGET_TOLERANCE})."
            )

        changed = np.abs(delta) > EPS_TOLERANCE
        intended = np.zeros_like(changed, dtype=bool)
        intended[:, attack_local_positions] = True

        non_selected_change = int(np.any(changed & ~intended))

        if non_selected_change:
            raise RuntimeError(
                f"{config_name}, epsilon={epsilon}: "
                "non-selected feature changed."
            )

        X_adv_raw = scaler.inverse_transform(
            X_adv_std
        ).astype(np.float32)

        if not np.isfinite(X_adv_raw).all():
            raise RuntimeError(
                f"{config_name}, epsilon={epsilon}: "
                "non-finite adversarial values."
            )

        adv_pred = model.predict(X_adv_raw)

        adv_f1 = float(
            f1_score(
                y_eval,
                adv_pred,
                average="macro",
                zero_division=0,
            )
        )

        absolute_drop = clean_eval_f1 - adv_f1
        retention = (
            adv_f1 / clean_eval_f1
            if clean_eval_f1 > 0
            else np.nan
        )
        prediction_change_rate = float(
            np.mean(eval_pred != adv_pred)
        )

        print(f"Clean Macro-F1       : {clean_eval_f1:.6f}")
        print(f"Adversarial Macro-F1 : {adv_f1:.6f}")
        print(f"Absolute drop        : {absolute_drop:.6f}")
        print(f"Retention            : {retention:.6f}")
        print(f"Max standardized Δ   : {max_std_delta:.8f}")
        print(f"Prediction change    : {prediction_change_rate:.6f}")
        print("Budget violation     : 0")
        print("Non-selected change  : 0")

        adv_rows.append({
            "Model": "RF",
            "Configuration": config_name,
            "Epsilon": epsilon,
            "Clean_Macro_F1": clean_eval_f1,
            "Adversarial_Macro_F1": adv_f1,
            "Absolute_Drop": absolute_drop,
            "Relative_Retention": retention,
            "Max_Standardized_Delta": max_std_delta,
            "Prediction_Change_Rate": prediction_change_rate,
            "Attack_Calibration_Rows": ATTACK_CALIBRATION_SIZE,
            "Attack_Evaluation_Rows": ATTACK_EVAL_SIZE,
            "Model_Features": len(features),
            "Attack_Features": len(attack_features),
            "Budget_Violation": budget_violation,
            "Non_Selected_Change": non_selected_change,
        })

        del X_adv_std, X_adv_raw, adv_pred, directions
        gc.collect()

    del X_cal_std, X_eval_std, scaler, eval_pred
    gc.collect()


def duplicate_results_for_alias(
    source_name: str,
    alias_name: str,
) -> None:
    """
    Copy already-computed clean/adv rows from source_name to
    alias_name (e.g. Quality-Only -> QARFS-0.00) without retraining
    or re-attacking — the underlying model and feature set are
    identical, so the results are identical by construction.
    """
    for row in clean_rows:
        if row["Configuration"] == source_name:
            new_row = dict(row)
            new_row["Configuration"] = alias_name
            clean_rows.append(new_row)
            break

    for row in adv_rows:
        if row["Configuration"] == source_name:
            new_row = dict(row)
            new_row["Configuration"] = alias_name
            adv_rows.append(new_row)


# --- Full (already trained in STEP 7) -----------------------------

print()
print("Evaluating and attacking: Full (78 features)")

run_clean_and_attack(
    config_name="Full",
    model=full_rf,
    features=FEATURE_COLUMNS,
    positions=np.arange(78, dtype=np.int64),
    attack_features=full_attack_features,
    training_seconds=full_rf_seconds,
)

del full_rf
gc.collect()

# --- Every unique reduced feature subset, trained once each --------

unique_reduced = {}
for config in selection_order:
    if config == "Full":
        continue
    key = tuple(selected[config])
    unique_reduced.setdefault(key, config)

for key, representative in unique_reduced.items():
    features = list(key)
    positions = np.array(
        [FEATURE_COLUMNS.index(f) for f in features],
        dtype=np.int64,
    )

    print()
    print(f"Training {representative}: {len(features)} features")

    t0 = time.time()

    model = rf_model()
    model.fit(
        X_train_subset[:, positions],
        y_train_subset,
    )

    training_seconds = time.time() - t0

    run_clean_and_attack(
        config_name=representative,
        model=model,
        features=features,
        positions=positions,
        attack_features=features,
        training_seconds=training_seconds,
    )

    # Any other config name in selection_order sharing this exact
    # feature set (e.g. QARFS-0.00 == Quality-Only) reuses these
    # results rather than retraining an identical model.
    for config in selection_order:
        if config == representative:
            continue
        if tuple(selected[config]) == key:
            duplicate_results_for_alias(representative, config)

    del model
    gc.collect()

# --- Save clean-performance summary (was dropped from STEP 10 in the
# original two-pass version's ending; restored here) -----------------

clean_df = pd.DataFrame(clean_rows)
clean_df["_order"] = clean_df["Configuration"].map(
    {name: i for i, name in enumerate(selection_order)}
)
clean_df = clean_df.sort_values("_order").drop(
    columns="_order"
)

clean_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_clean.csv",
    index=False,
)

print()
print(
    clean_df[
        [
            "Configuration",
            "Feature_Count",
            "Clean_Test_Macro_F1",
            "Clean_Eval_Macro_F1",
        ]
    ].to_string(index=False)
)


# ============================================================
# STEP 12 — SAVE RESULTS
# ============================================================

adv_df = pd.DataFrame(adv_rows)

expected_conditions = (
    len(selection_order) * len(EPSILONS)
)

if len(adv_df) != expected_conditions:
    raise RuntimeError(
        f"Expected {expected_conditions} conditions; "
        f"got {len(adv_df)}."
    )

if int(adv_df["Budget_Violation"].sum()) != 0:
    raise RuntimeError(
        "At least one epsilon budget violation occurred."
    )

if int(adv_df["Non_Selected_Change"].sum()) != 0:
    raise RuntimeError(
        "At least one non-selected feature changed."
    )

adv_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_adversarial.csv",
    index=False,
)


# ============================================================
# STEP 13 — SUMMARY
# ============================================================

summary = (
    adv_df
    .groupby(
        ["Model", "Configuration"],
        as_index=False,
    )
    .agg(
        Clean_Macro_F1=(
            "Clean_Macro_F1",
            "first",
        ),
        Mean_Adv_Macro_F1=(
            "Adversarial_Macro_F1",
            "mean",
        ),
        Mean_Absolute_Drop=(
            "Absolute_Drop",
            "mean",
        ),
        Worst_Absolute_Drop=(
            "Absolute_Drop",
            "max",
        ),
        Mean_Retention=(
            "Relative_Retention",
            "mean",
        ),
        Worst_Retention=(
            "Relative_Retention",
            "min",
        ),
        Mean_Prediction_Change_Rate=(
            "Prediction_Change_Rate",
            "mean",
        ),
        Feature_Count=(
            "Model_Features",
            "first",
        ),
        Attack_Feature_Count=(
            "Attack_Features",
            "first",
        ),
    )
)

summary["_order"] = summary["Configuration"].map(
    {name: i for i, name in enumerate(selection_order)}
)

summary = summary.sort_values(
    "_order"
).drop(columns="_order")

summary.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_summary.csv",
    index=False,
)

print()
print("FINAL SUMMARY")
print(
    summary[
        [
            "Configuration",
            "Clean_Macro_F1",
            "Mean_Adv_Macro_F1",
            "Mean_Absolute_Drop",
            "Worst_Absolute_Drop",
            "Mean_Retention",
        ]
    ].to_string(index=False)
)


# ============================================================
# STEP 14 — FINAL AUDIT
# ============================================================

header("STEP 14 — FINAL AUDIT")

audit_rows = [
    ("Status", "PASS"),
    ("CSV_Files", len(files)),
    ("Raw_Rows", total_raw_rows),
    ("Embedded_Header_Rows", total_embedded_headers),
    ("Usable_Rows", usable_rows),
    ("Classes", len(label_encoder.classes_)),
    ("ML_Features", len(FEATURE_COLUMNS)),
    ("Attackable_Features", len(attackable_features)),
    ("Training_Subset_Rows", len(y_train_subset)),
    ("Attack_Calibration_Rows", ATTACK_CALIBRATION_SIZE),
    ("Attack_Evaluation_Rows", ATTACK_EVAL_SIZE),
    ("Reduced_Selected_Features", N_SELECTED),
    ("Configurations", len(selection_order)),
    ("Epsilons", "0.05,0.10,0.20"),
    ("Conditions", len(adv_df)),
    ("Budget_Violations", int(
        adv_df["Budget_Violation"].sum()
    )),
    ("Non_Selected_Changes", int(
        adv_df["Non_Selected_Change"].sum()
    )),
    ("QARFS_Alpha_0_Equals_Quality",
     selected["QARFS-0.00"] == selected["Quality-Only"]),
    ("QARFS_Alpha_1_Equals_Importance",
     selected["QARFS-1.00"] == selected["Importance-Only"]),
    ("QARFS_Candidate_Pool", "All 78 ML features"),
    ("Full_Attack_Features", len(full_attack_features)),
    ("Attack_Budget", "|delta_z| <= epsilon"),
    ("Raw_IQR_Attack_Constraint", "None"),
    ("Attack_Type",
     "Greedy finite-difference universal black-box"),
    ("True_Feature_Selection", "Yes"),
    ("Retrain_Per_Unique_Subset", "Yes"),
    ("Calibration_Evaluation_Disjoint", "Yes"),
    ("G30_Full_RF_Macro_F1",
     full_test_metrics["Macro_F1"]),
]

audit_df = pd.DataFrame(
    audit_rows,
    columns=["Check", "Value"],
)

audit_df.to_csv(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_audit.csv",
    index=False,
)

with open(
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_audit.txt",
    "w",
    encoding="utf-8",
) as f:
    f.write(
        "G34 FINAL TRUE CSE-CIC-IDS2018 QARFS AUDIT\n"
    )
    f.write("=" * 80 + "\n\n")
    f.write(audit_df.to_string(index=False))
    f.write("\n\nSUMMARY\n")
    f.write(summary.to_string(index=False))
    f.write("\n\nFILE AUDIT\n")
    f.write(
        pd.DataFrame(file_audit).to_string(
            index=False
        )
    )

print()
print("=" * 80)
print("G34 FINAL TRUE QARFS — COMPLETE PASS")
print("=" * 80)
print("Conditions completed :", len(adv_df))
print("Budget violations     :", int(
    adv_df["Budget_Violation"].sum()
))
print("Non-selected changes  :", int(
    adv_df["Non_Selected_Change"].sum()
))
print()
print(
    "Summary:",
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_summary.csv",
)
print(
    "Clean:",
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_clean.csv",
)
print(
    "Adversarial:",
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_adversarial.csv",
)
print(
    "Audit:",
    RESULTS_DIR
    / "step_G34_CSE_CIC_IDS2018_QARFS_audit.csv",
)
