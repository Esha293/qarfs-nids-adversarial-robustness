"""
make_figures.py

Generates Figures 1-4 for the QARFS paper DIRECTLY from the actual
result CSVs produced by G34_FINAL_TRUE_CSE_CIC_IDS2018_QARFS.py.

No numbers are hardcoded anywhere in this script. Every value plotted
is computed live from:
    step_G34_CSE_CIC_IDS2018_QARFS_clean.csv
    step_G34_CSE_CIC_IDS2018_QARFS_adversarial.csv
    step_G34_CSE_CIC_IDS2018_QARFS_feature_selection.csv

Run this yourself against your own CSVs to verify every figure
independently.
"""

import itertools
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pathlib import Path

IN_DIR = Path(r"D:\DCIC_IDS_Project\results")
OUT_DIR = Path(r"D:\DCIC_IDS_Project\figures")
OUT_DIR.mkdir(parents=True, exist_ok=True)

CLEAN_CSV = IN_DIR / "step_G34_CSE_CIC_IDS2018_QARFS_clean.csv"
ADV_CSV = IN_DIR / "step_G34_CSE_CIC_IDS2018_QARFS_adversarial.csv"
SEL_CSV = IN_DIR / "step_G34_CSE_CIC_IDS2018_QARFS_feature_selection.csv"

# Display order for all figures (matches the paper's table order)
CONFIG_ORDER = [
    "Full",
    "Quality-Only",
    "QARFS-0.25",
    "QARFS-0.50",
    "QARFS-0.75",
    "Importance-Only",
    "Random",
    "MutualInfo-Only",
]

plt.rcParams.update({
    "font.size": 11,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
})


def load_data():
    clean = pd.read_csv(CLEAN_CSV)
    adv = pd.read_csv(ADV_CSV)
    sel = pd.read_csv(SEL_CSV)
    return clean, adv, sel


# ---------------------------------------------------------------
# Figure 1 — Clean vs. Adversarial Macro-F1 trade-off
# ---------------------------------------------------------------
def figure1(clean, adv):
    # Mean adversarial Macro-F1 per configuration, computed live
    # from the adversarial CSV (averaged across the 3 epsilons).
    mean_adv = (
        adv.groupby("Configuration")["Adversarial_Macro_F1"]
        .mean()
        .to_dict()
    )

    # Clean eval Macro-F1 per configuration, taken directly from the
    # clean CSV (this is the same clean value the adversarial rows
    # were compared against).
    clean_map = clean.set_index("Configuration")[
        "Clean_Eval_Macro_F1"
    ].to_dict()

    configs = [c for c in CONFIG_ORDER if c in clean_map]
    clean_vals = [clean_map[c] for c in configs]
    adv_vals = [mean_adv[c] for c in configs]

    x = np.arange(len(configs))
    width = 0.35

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(x - width / 2, clean_vals, width, label="Clean Macro-F1")
    ax.bar(x + width / 2, adv_vals, width, label="Mean Adversarial Macro-F1")

    ax.set_xticks(x)
    ax.set_xticklabels(configs, rotation=30, ha="right")
    ax.set_ylabel("Macro-F1")
    ax.set_title("Clean vs. Adversarial Macro-F1 by Configuration")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)

    fig.savefig(OUT_DIR / "figure1_clean_vs_adversarial.png")
    plt.close(fig)

    print("Figure 1 data used:")
    for c, cl, av in zip(configs, clean_vals, adv_vals):
        print(f"  {c:16s} clean={cl:.4f}  mean_adv={av:.4f}")


# ---------------------------------------------------------------
# Figure 2 — Effect of alpha on clean performance and retention
# ---------------------------------------------------------------
def figure2(clean, adv):
    alpha_configs = [
        ("0.00", "QARFS-0.00"),
        ("0.25", "QARFS-0.25"),
        ("0.50", "QARFS-0.50"),
        ("0.75", "QARFS-0.75"),
        ("1.00", "QARFS-1.00"),
    ]

    clean_map = clean.set_index("Configuration")[
        "Clean_Eval_Macro_F1"
    ].to_dict()
    mean_ret = (
        adv.groupby("Configuration")["Relative_Retention"]
        .mean()
        .to_dict()
    )

    alphas = [float(a) for a, _ in alpha_configs]
    clean_vals = [clean_map[cfg] for _, cfg in alpha_configs]
    retention_vals = [mean_ret[cfg] * 100 for _, cfg in alpha_configs]

    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax2 = ax1.twinx()

    l1, = ax1.plot(
        alphas, clean_vals, "o-", color="tab:blue", label="Clean Macro-F1"
    )
    l2, = ax2.plot(
        alphas, retention_vals, "s--", color="tab:red",
        label="Mean Retention (%)"
    )

    ax1.set_xlabel(r"$\alpha$")
    ax1.set_ylabel("Clean Macro-F1", color="tab:blue")
    ax2.set_ylabel("Mean Retention (%)", color="tab:red")
    ax1.set_title(r"Effect of $\alpha$ on Clean Performance and Retention")
    ax1.grid(alpha=0.3)
    ax1.legend(handles=[l1, l2], loc="center right")

    fig.savefig(OUT_DIR / "figure2_alpha_effect.png")
    plt.close(fig)

    print("\nFigure 2 data used:")
    for a, cl, rt in zip(alphas, clean_vals, retention_vals):
        print(f"  alpha={a:.2f}  clean={cl:.4f}  retention={rt:.2f}%")


# ---------------------------------------------------------------
# Figure 3 — Adversarial Macro-F1 across perturbation strengths
# ---------------------------------------------------------------
def figure3(adv):
    epsilons = sorted(adv["Epsilon"].unique())
    configs = [c for c in CONFIG_ORDER if c in adv["Configuration"].unique()]

    fig, ax = plt.subplots(figsize=(9, 5.5))

    for cfg in configs:
        sub = adv[adv["Configuration"] == cfg].sort_values("Epsilon")
        ax.plot(
            sub["Epsilon"], sub["Adversarial_Macro_F1"],
            marker="o", label=cfg,
        )

    ax.set_xlabel(r"$\epsilon$")
    ax.set_ylabel("Adversarial Macro-F1")
    ax.set_title("Adversarial Macro-F1 Across Perturbation Strengths")
    ax.set_xticks(epsilons)
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=9)
    ax.grid(alpha=0.3)

    fig.savefig(OUT_DIR / "figure3_epsilon_sweep.png")
    plt.close(fig)

    print("\nFigure 3 data used:")
    for cfg in configs:
        sub = adv[adv["Configuration"] == cfg].sort_values("Epsilon")
        vals = ", ".join(
            f"{e:.2f}:{v:.4f}"
            for e, v in zip(sub["Epsilon"], sub["Adversarial_Macro_F1"])
        )
        print(f"  {cfg:16s} {vals}")


# ---------------------------------------------------------------
# Figure 4 — Jaccard similarity heatmap
# ---------------------------------------------------------------
def figure4(sel):
    reduced_configs = [
        "Quality-Only", "QARFS-0.25", "QARFS-0.50", "QARFS-0.75",
        "Importance-Only", "Random", "MutualInfo-Only",
    ]

    feature_sets = {
        c: set(sel[sel["Configuration"] == c]["Feature"].tolist())
        for c in reduced_configs
    }

    n = len(reduced_configs)
    jac_matrix = np.zeros((n, n))

    for i, a in enumerate(reduced_configs):
        for j, b in enumerate(reduced_configs):
            inter = feature_sets[a] & feature_sets[b]
            union = feature_sets[a] | feature_sets[b]
            jac_matrix[i, j] = len(inter) / len(union) if union else 0.0

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(jac_matrix, cmap="viridis", vmin=0, vmax=1)

    ax.set_xticks(range(n))
    ax.set_yticks(range(n))
    ax.set_xticklabels(reduced_configs, rotation=45, ha="right")
    ax.set_yticklabels(reduced_configs)

    for i, j in itertools.product(range(n), range(n)):
        ax.text(
            j, i, f"{jac_matrix[i, j]:.2f}",
            ha="center", va="center",
            color="white" if jac_matrix[i, j] < 0.5 else "black",
            fontsize=8,
        )

    fig.colorbar(im, ax=ax, label="Jaccard similarity")
    ax.set_title("Pairwise Feature-Selection Jaccard Similarity")

    fig.savefig(OUT_DIR / "figure4_jaccard_heatmap.png")
    plt.close(fig)

    print("\nFigure 4 data used (Jaccard matrix):")
    header = "".join(f"{c[:10]:>12s}" for c in reduced_configs)
    print(" " * 16 + header)
    for i, a in enumerate(reduced_configs):
        row = "".join(f"{jac_matrix[i, j]:12.4f}" for j in range(n))
        print(f"{a:16s}{row}")


if __name__ == "__main__":
    clean_df, adv_df, sel_df = load_data()

    print(f"Loaded clean CSV: {clean_df.shape[0]} rows")
    print(f"Loaded adversarial CSV: {adv_df.shape[0]} rows")
    print(f"Loaded feature-selection CSV: {sel_df.shape[0]} rows")
    print()

    figure1(clean_df, adv_df)
    figure2(clean_df, adv_df)
    figure3(adv_df)
    figure4(sel_df)

    print("\nAll figures saved to:", OUT_DIR)
